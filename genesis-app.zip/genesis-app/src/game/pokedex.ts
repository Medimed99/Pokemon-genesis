// Mini-roster pour la tranche de l'Acte I. Les sprites sont tirés en direct de
// PokeAPI (approche héritée de l'ancien repo) — aucun asset à stocker.

export interface Species {
  id: number;
  name: string;
  type: 'Plante' | 'Feu' | 'Eau' | 'Normal';
  bst: number;
}

export const STARTERS: Species[] = [
  { id: 1, name: 'Bulbizarre', type: 'Plante', bst: 318 },
  { id: 4, name: 'Salamèche', type: 'Feu', bst: 309 },
  { id: 7, name: 'Carapuce', type: 'Eau', bst: 314 },
];

export function spriteUrl(id: number, shiny = false): string {
  const base = 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon';
  return shiny ? `${base}/shiny/${id}.png` : `${base}/${id}.png`;
}

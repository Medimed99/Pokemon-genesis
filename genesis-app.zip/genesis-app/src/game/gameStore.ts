import { create } from 'zustand';
import { EconomyStore } from '../engine/economyStore.ts';
import { ModuleRegistry } from '../engine/module.ts';
import type { ResourceId } from '../engine/resources.ts';
import { ALL_MODULES } from './modules.ts';
import { STARTERS, type Species } from './pokedex.ts';
import { INTRO, type Phase } from './narrative.ts';
import type { GameSave } from './save/SaveAdapter.ts';

// Singletons découplés de React : le moteur vit ici, l'UI ne fait que le refléter.
export const economy = new EconomyStore();
const registry = new ModuleRegistry({ economy });
ALL_MODULES.forEach((m) => registry.register(m));

export interface Worker {
  species: Species;
  level: number;
  shiny: boolean;
}

// PPS = (BST/10) × rareté × bonus de type × shiny × niveau  (cf. GDD §4.2)
export function workerPps(w: Worker): number {
  const rarity = 1; // starters = communs
  const typeMatch = w.species.type === 'Plante' ? 1.2 : 1; // Forêt de Jade = habitat Plante
  const shiny = w.shiny ? 10 : 1;
  return (w.species.bst / 10) * rarity * typeMatch * shiny * w.level;
}

interface GameState {
  balances: Record<ResourceId, number>;
  phase: Phase;
  introIndex: number;
  colorsReturned: boolean;
  workers: Worker[];
  clickPower: number;
  totalPps: () => number;
  nextIntro: () => void;
  tapNoyau: () => void;
  compileSignal: () => void;
  tick: (seconds: number) => void;
  hydrate: (save: GameSave) => void;
  toSave: () => GameSave;
}

export const useGame = create<GameState>((set, get) => ({
  balances: economy.snapshot(),
  phase: 'intro',
  introIndex: 0,
  colorsReturned: false,
  workers: [],
  clickPower: 1,

  totalPps: () => get().workers.reduce((acc, w) => acc + workerPps(w), 0),

  nextIntro: () => {
    const { introIndex } = get();
    if (introIndex < INTRO.length - 1) set({ introIndex: introIndex + 1 });
    else set({ phase: 'tap' });
  },

  tapNoyau: () => {
    economy.grant({ eo: get().clickPower });
    if (get().phase === 'tap' && economy.getBalance('eo') >= 10) set({ phase: 'worker' });
  },

  // Tient lieu de Blind Box pour la tranche : compile un starter dans la Forêt.
  compileSignal: () => {
    const owned = get().workers.length;
    const species = STARTERS[owned % STARTERS.length];
    const shiny = Math.random() < 0.05;
    set((s) => ({ workers: [...s.workers, { species, level: 1, shiny }] }));
    if (!get().colorsReturned) set({ colorsReturned: true, phase: 'free' });
  },

  tick: (seconds) => {
    economy.tick(seconds);
    const gain = get().totalPps() * seconds;
    if (gain > 0) economy.grant({ eo: gain });
  },

  hydrate: (save) => {
    economy.load(save.economy);
    const workers: Worker[] = save.workers.map((w) => ({
      species: STARTERS.find((s) => s.id === w.speciesId) ?? STARTERS[0],
      level: w.level,
      shiny: w.shiny,
    }));
    set({
      workers,
      phase: (save.phase as Phase) ?? 'intro',
      colorsReturned: save.colorsReturned,
    });
  },

  toSave: () => ({
    economy: economy.serialize(),
    workers: get().workers.map((w) => ({ speciesId: w.species.id, level: w.level, shiny: w.shiny })),
    phase: get().phase,
    colorsReturned: get().colorsReturned,
  }),
}));

// Refléter chaque changement de l'économie dans le store React.
economy.subscribe((balances) => useGame.setState({ balances: { ...balances } }));

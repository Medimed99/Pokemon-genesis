const DOORS = [
  { id: 'expedition', label: 'Expédition Arcanes', sub: 'Roguelike · Acte II' },
  { id: 'poker', label: 'Poké-Poker', sub: 'Deckbuilder · Acte III' },
];

export default function ModuleDoors() {
  return (
    <div className="doors">
      {DOORS.map((d) => (
        <div className="door locked" key={d.id}>
          <div className="door-lock">⌧</div>
          <div className="door-label">{d.label}</div>
          <div className="door-sub">{d.sub}</div>
          <div className="door-status">bientôt en ligne</div>
        </div>
      ))}
    </div>
  );
}
